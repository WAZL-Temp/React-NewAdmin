import { useEffect, useState } from "react";
import { useAuthStore } from "../store/authStore";
import { LookupServiceBase } from "../sharedBase/lookupService";
import { AiFillHome, FiShoppingBag, FiUser, IoPersonSharp, RiLogoutCircleLine, RxCross2, Tooltip, useLocation, useNavigate, useTranslation } from "../sharedBase/globalImports";


interface SidebarProps {
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  isMinimized: boolean;
  toggleMinimized: () => void;
}

const Sidebar = ({ isSidebarOpen, toggleSidebar, isMinimized }: SidebarProps) => {
  const { t } = useTranslation();
  const login = useAuthStore((state) => state.login);
  const userInfo = useAuthStore((state) => state.userInfo);
  const [roleData, setRoleData] = useState<any>([])
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const getRoleData = async () => {
      const lookupService = new LookupServiceBase();
      const roleDetails = await lookupService.fetchRoleDetailsData();

      if (Array.isArray(roleDetails) && roleDetails.length > 0) {
        setRoleData(roleDetails);
      }
    };

    getRoleData();
  }, []);

  const hasAccess = (roleData: any, requiredAction: string) => {
    if (!roleData) return false;

    const actions = typeof roleData.action === "string" ? JSON.parse(roleData.action) : [];

    return actions.some((action: any) => action.name.toLowerCase() === requiredAction.toLowerCase());
  }

  const handleLogout = () => {
    login("");
    userInfo("");
    window.location.href = "/";
    toggleSidebar();
  };

  const hasAccessToPage = (pageName: string) => {
    return roleData.some((action: any) => action.name.toLowerCase() === pageName.toLowerCase());
  }

  const handleNavigation = (path: string) => {
    if (hasAccessToPage(path.slice(1))) {
      navigate(path);
    } else {
      navigate("/404");
    }
    toggleSidebar();
  }

  return (
    <aside
      className={`fixed inset-y-0 left-0 z-50 sidebar bg-[var(--color-primary)] text-[var(--color-white)] border border-muted/40 transform transition-transform duration-300 ease-in-out 
      ${isSidebarOpen ? "translate-x-0" : "-translate-x-full"} 
      lg:relative lg:translate-x-0 
      ${isMinimized && window.innerWidth >= 1024 ? "w-16" : "w-[170px]"} flex flex-col justify-between h-full`}
    >

      <div className="bg-[var(--color-primary)] sidebar md:hidden lg:hidden mb-14">
        <button
          className="absolute top-4 right-4 text-[var(--color-primary)] bg-[var(--color-white)] p-1 rounded-md"
          onClick={toggleSidebar}
        >
          <RxCross2 size={20} />
        </button>
      </div>

      <nav
        className={`flex-1 overflow-y-auto overflow-x-hidden p-2 lg:p-3 space-y-2 bg-[var(--color-primary)] text-[var(--color-white)] `}
      >

        <button
          onClick={() => {
            navigate("/appuser/homes");
            toggleSidebar();
          }}
          className={`flex items-center ${isMinimized ? 'px-1' : 'px-2'} py-2 rounded
          ${location.pathname === "/appuser/homes" ? "bg-[var(--color-white)] text-[var(--color-primary)]" : "bg-[var(--color-primary)] text-[var(--color-white)]"}
          hover:bg-[var(--color-white)] hover:text-[var(--color-primary)]`}
          data-pr-tooltip={t("globals.homes")}
          data-pr-position="right"
          id="home-tooltip"
        >
          <AiFillHome size={18} className={`${isMinimized ? '' : 'mr-3'}`} />
          {(!isMinimized) && <span className=" text-sm font-medium">{t("globals.homes")}</span>}
        </button>

        <button
          onClick={() => {
            navigate("/appusertests");
            toggleSidebar();
          }}
          className={`flex items-center ${isMinimized ? 'px-1' : 'px-2'} py-2 rounded
          ${location.pathname === "/appusertests" ? "bg-[var(--color-white)] text-[var(--color-primary)]" : "bg-[var(--color-primary)] text-[var(--color-white)]"}
          hover:bg-[var(--color-white)] hover:text-[var(--color-primary)]`}
          data-pr-tooltip={t("appUsers.form_detail.fields.modelname")}
          data-pr-position="right"
          id="list-tooltip"
        >
          <FiUser size={18} className={`${isMinimized ? '' : 'mr-3'}`} />
          {(!isMinimized) && <span className=" text-sm font-medium">AppuserTest</span>}
        </button>

        {hasAccess(roleData.find((r: any) => r.name.toLowerCase() === 'product'), "List") && (
          <button
            onClick={() => handleNavigation("/product")}
            className={`flex items-center ${isMinimized ? 'px-1' : 'px-2'} py-2 rounded
            ${location.pathname === "/product" ? "bg-[var(--color-white)] text-[var(--color-primary)]" : "bg-[var(--color-primary)] text-[var(--color-white)]"}
            hover:bg-[var(--color-white)] hover:text-[var(--color-primary)]`}
            data-pr-tooltip={t("products.form_detail.fields.modelname")}
            data-pr-position="right"
            id="product-tooltip"
          >
            <FiShoppingBag size={18} className={`${isMinimized ? '' : 'mr-3'}`} />
            {(!isMinimized) && <span className=" text-sm font-medium">{t("products.form_detail.fields.modelname")}</span>}
          </button>
        )}

        <button
          onClick={() => {
            navigate("/role");
            toggleSidebar();
          }}
          className={`flex items-center ${isMinimized ? 'px-1' : 'px-2'} py-2 rounded
          ${location.pathname === "/role" ? "bg-[var(--color-white)] text-[var(--color-primary)]" : "bg-[var(--color-primary)] text-[var(--color-white)]"}
          hover:bg-[var(--color-white)] hover:text-[var(--color-primary)]`}
          data-pr-tooltip={t("appUsers.columns.fields.role")}
          data-pr-position="right"
          id="role-tooltip"
        >
          <IoPersonSharp size={18} className={`${isMinimized ? '' : 'mr-3'}`} />
          {(!isMinimized) && <span className=" text-sm font-medium">{t("appUsers.columns.fields.role")}</span>}
        </button>

        <Tooltip target="#home-tooltip" className="text-xs lg:text-sm p-0 hide-tooltip-mobile" />
        <Tooltip target="#list-tooltip" className="text-xs lg:text-sm p-0 hide-tooltip-mobile" />
        <Tooltip target="#product-tooltip" className="text-xs lg:text-sm p-0 hide-tooltip-mobile" />
      </nav>

      <footer className="flex justify-center items-center p-2 border-t bg-[var(--color-primary)] text-[var(--color-white)] ">
        <button
          onClick={handleLogout}
          className={`flex items-center justify-center py-2 rounded ${isMinimized ? "px-1 " : "px-2"} bg-[var(--color-primary)] text-[var(--color-white)] 
         hover:bg-[var(--color-white)] hover:text-[var(--color-primary)] ${isMinimized && !isSidebarOpen ? "justify-center" : ""}`}
        >
          <RiLogoutCircleLine size={18} className={`${isMinimized ? '' : 'mr-3'}`} />
          {(!isMinimized) && <span className="text-sm font-medium">{t("globals.logout")}</span>}
        </button>
      </footer>
    </aside >
  );
};

export default Sidebar;
