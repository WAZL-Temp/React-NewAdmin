
export interface AllNotification {
	createDate?: Date;
	id?: number;
	name?: string;
	url?: string;
	image?: string;
	appUserId?: string;
	shortDescription?: string;
	description?: string;
	updateDate?: Date;
	deleteDate?: Date;
	createById?: number;
	updateById?: number;
	deleteById?: number;
	isDelete?: boolean;
}
