import { BaseService } from "../../sharedBase/baseService";
import { RoleDetail } from "../model/roledetail";

export const roleDetailService = new BaseService<RoleDetail>("RoleDetail");
