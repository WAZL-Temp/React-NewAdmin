import { BaseService } from "../../sharedBase/baseService";
import { EnumDetail } from "../model/enumdetail";

export const enumDetailsService = new BaseService<EnumDetail>("EnumDetail");

