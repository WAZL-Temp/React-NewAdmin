import { BaseService } from "../../sharedBase/baseService";
import { RoleData } from "../model/roledata";


export const roleDataService = new BaseService<RoleData>("RoleData");