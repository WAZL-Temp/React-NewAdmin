import { createListStore } from "../../../store/createListStore";
import { RoleData } from "../../../core/model/roledata";
import { roleDataService } from "../../../core/services/roleDataService";


export const roleDataStore = createListStore<RoleData>(roleDataService, "RoleData");
