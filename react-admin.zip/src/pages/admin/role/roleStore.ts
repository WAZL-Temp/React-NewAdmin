import { roleService } from "../../../core/services/roleService";
import { createListStore } from "../../../store/createListStore";
import { Role } from "../../../core/model/role";

export const roleStore = createListStore<Role>(roleService, "Role");



