import { createListStore } from "../../../store/createListStore";
import { RoleDetail } from "../../../core/model/roledetail";
import { roleDetailService } from "../../../core/services/roleDetailService";


export const roleDetailStore = createListStore<RoleDetail>(roleDetailService, "RoleDetail");
