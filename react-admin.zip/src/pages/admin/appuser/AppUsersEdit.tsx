import { useEffect, useRef, useState } from 'react'
import { appUserItemStore, appUserListStore } from "./appUserStore";
import successImg from '../../../assets/images/success.gif'
import { BsArrowLeft, Button, Calendar, Checkbox, Dialog, Dropdown, FaSave, Image, InputText, InputTextarea, IoIosArrowBack, IoIosArrowForward, Stepper, StepperPanel, Toast, useNavigate, useParams, useTranslation } from '../../../sharedBase/globalImports';
import { useEditPage } from '../../../hooks/useEditPage';
import { AppUser } from '../../../core/model/appuser';
import { selectDropdownEnum } from '../../../sharedBase/dropdownUtils';
import { getGlobalSchema } from '../../../globalschema';
import TooltipWithText from '../../../components/TooltipWithText';
import FileUploadMain from '../../../components/FileUploadMain';
import { LookupServiceBase } from '../../../sharedBase/lookupService';

interface CustomFile {
  fileName: string;
  filePath: string;
  type: string;
}

export default function AppUsersEdit() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const globalschema = getGlobalSchema(t);
  const toast = useRef<Toast>(null);
  const baseModelName = "appuser";
  const itemStore = appUserItemStore();
  const listStore = appUserListStore();
  const isEditMode = Boolean(id);
  const stepperRef = useRef<any>(null);
  const [formData, setFormData] = useState({ id: "", name: "", firstName: "", lastName: "", mobile: "", mobileVerified: false, emailId: "", emailVerified: false, shopName: "", password: "", pincode: "", state: "", district: "", address: "", addressLine: "", verifyShop: "", gst: "", gstCertificate: "", photoShopFront: "", visitingCard: "", cheque: "", gstOtp: "", isActive: false, isAdmin: false, hasImpersonateAccess: false, photoAttachment: "", role: "", publish: "", lastLogin: "", defaultLanguage: "", isPremiumUser: false, totalPlot: "" });
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [stepNo, setStepNo] = useState(0);
  const headers = [
    t("appUsers.form_detail.fields.accessDetails"),
    t("appUsers.form_detail.fields.shopDetails"),
    t("appUsers.form_detail.fields.shopAddress"),
    t("appUsers.form_detail.fields.verifyShop"),
  ];

  const [listVerifyShop, setListVerifyShop] = useState<any[]>([]);
  const [listRoles, setListRoles] = useState<any[]>([]);
  const [listPublishes, setListPublishes] = useState<any[]>([]);

  const [selectedVerifyShop, setSelectedVerifyShop] = useState<any | null>(null);
  const [selectedRoles, setSelectedRoles] = useState<any | null>(null);
  const [selectedPublishes, setSelectedPublishes] = useState<any | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [dialogMessage, setDialogMessage] = useState('');
  const requiredFieldsMap: { [key: number]: string[] } = {
    0: ['name', 'mobile'],
    1: [],
    2: [],
    3: ['role', 'publish'],
  };

  useEffect(() => {
    if (isEditMode) {
      itemStore.getItem(parseInt(id as string, 10));
    }
  }, [id]);

  const { showDialog, setShowDialog, isFieldHidden, handleCloseDialog, formatDate, removeEmptyFields }
    = useEditPage<typeof itemStore, AppUser>({
      store: appUserItemStore(),
      props: {
        id: id,
        baseModelName: baseModelName,
        listStore: listStore
      }
    });

  useEffect(() => {
    if (!itemStore.data) return;

    if (isEditMode) {
      const formattedData = {
        id: itemStore.data.id ? String(itemStore.data.id) : '',
        name: itemStore.data.name || '',
        firstName: itemStore.data.firstName || '',
        lastName: itemStore.data.lastName || '',
        mobile: itemStore.data.mobile || '',
        mobileVerified: itemStore.data.mobileVerified ?? false,
        emailId: itemStore.data.emailId || '',
        emailVerified: itemStore.data.emailVerified ?? false,
        shopName: itemStore.data.shopName || '',
        password: itemStore.data.password || '',
        pincode: itemStore.data.pincode || '',
        state: itemStore.data.state || '',
        district: itemStore.data.district || '',
        address: itemStore.data.address || '',
        addressLine: itemStore.data.addressLine || '',
        verifyShop: itemStore.data.verifyShop || '',
        gst: itemStore.data.gst || '',
        gstCertificate: itemStore.data.gstCertificate || '',
        photoShopFront: itemStore.data.photoShopFront || '',
        visitingCard: itemStore.data.visitingCard || '',
        cheque: itemStore.data.cheque || '',
        gstOtp: itemStore.data.gstOtp || '',
        isActive: itemStore.data.isActive ?? false,
        isAdmin: itemStore.data.isAdmin ?? false,
        hasImpersonateAccess: itemStore.data.hasImpersonateAccess ?? false,
        photoAttachment: itemStore.data.photoAttachment || '',
        role: itemStore.data.role || '',
        publish: itemStore.data.publish || '',
        isPremiumUser: itemStore.data.isPremiumUser ?? false,
        totalPlot: itemStore.data.totalPlot !== undefined ? String(itemStore.data.totalPlot) : '',
        lastLogin: itemStore.data.lastLogin
          ? new Date(itemStore.data.lastLogin).toISOString()
          : '',
        defaultLanguage: itemStore.data.defaultLanguage || '',
      };
      setFormData(formattedData);

      const setDateCalenderValues = () => {
        if (itemStore.data && itemStore.data.lastLogin) {
          const calendarLastLogin = new Date(itemStore.data.lastLogin);
          setFormData((prevFormData) => ({
            ...prevFormData,
            lastLogin: calendarLastLogin.toISOString(),
          }));
        }
      };
      setDateCalenderValues();
    }
  }, [itemStore.data]);

  useEffect(() => {
    const bindDropDownList = async () => {
      const lookupService = new LookupServiceBase();
      const roleData = await lookupService.fetchDataEnum("RoleType");
      setListRoles(roleData);
      if (itemStore.data && itemStore.data.role) {
        const selectedList = roleData.filter(
          (a: any) => itemStore.data && a.value === itemStore.data.role
        );
        if (selectedList.length) {
          setSelectedRoles(selectedList[0].value);
        }
      }

      const publishTypeData = await lookupService.fetchDataEnum("PublishType");
      setListPublishes(publishTypeData);
      if (itemStore.data && itemStore.data.publish) {
        const selectedList = publishTypeData.filter(
          (a: any) => itemStore.data && a.value === itemStore.data.publish
        );
        if (selectedList.length) {
          setSelectedPublishes(selectedList[0].value);
        }
      }

      const verifshopData = await lookupService.fetchDataEnum("VerifyType");
      setListVerifyShop(verifshopData);
      if (itemStore.data && itemStore.data.verifyShop) {
        const selectedList = verifshopData.filter(
          (a: any) => itemStore.data && a.value === itemStore.data.verifyShop
        );
        if (selectedList.length) {
          setSelectedVerifyShop(selectedList[0].value);
        }
      }
    };
    bindDropDownList();
  }, []);

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    const schema = globalschema[field as keyof typeof globalschema];

    if (schema) {
      const result = schema.safeParse(value);
      if (result.success) {
        setErrors((prev) => ({ ...prev, [field]: '' }));
      } else {
        setErrors((prev) => ({
          ...prev,
          [field]: result.error.errors[0].message,
        }));
      }
    }
  };

  const handleFileUpload = (files: CustomFile[], inputName: string) => {
    setFormData(prevData => ({
      ...prevData,
      [inputName]: JSON.stringify(files)
    }));
  };

  const handleBackToUser = () => {
    navigate("/appuser");
  };

  const handleCheckboxChange = (e: { checked?: boolean }, key: string) => {
    const value = e.checked ?? false;

    setFormData((prev) => ({
      ...prev,
      [key]: value,
    }));

    const schema = globalschema[key as keyof typeof globalschema];
    if (schema) {
      const result = schema.safeParse(value);
      if (result.success) {
        setErrors((prev) => ({ ...prev, [key]: '' }));
      } else {
        setErrors((prev) => ({
          ...prev,
          [key]: result.error.errors[0].message,
        }));
      }
    }
  };

  const validateStepFields = (step: number) => {
    const requiredFields = requiredFieldsMap[step] || [];
    let hasError = false;
    const newErrors: Record<string, string> = { ...errors };

    requiredFields.forEach((field) => {
      const value = formData[field as keyof typeof formData];
      const schema = globalschema[field as keyof typeof globalschema];
      if (schema) {
        const result = schema.safeParse(value);
        if (!result.success) {
          newErrors[field] = result.error.errors[0].message;
          hasError = true;
        } else {
          newErrors[field] = '';
        }
      } else if (value === '' || value === false) {
        newErrors[field] = 'This field is required';
        hasError = true;
      }
    });

    setErrors(newErrors);
    return !hasError;
  };

  const next = () => {
    const isValid = validateStepFields(stepNo);
    if (!isValid) {
      return;
    }

    if (stepNo <= headers?.length) {
      setStepNo((prev) => prev + 1);
      stepperRef.current.nextCallback();
    }
  };

  const previous = () => {
    setStepNo((prev) => (prev > 0 ? prev - 1 : 0));
    stepperRef.current.prevCallback();
  };

  const handleSubmitClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    // event.preventDefault();
    // const form = document.getElementById("myForm") as HTMLFormElement | null;
    // if (form) {
    //   form.requestSubmit();
    // }
    const isValid = validateStepFields(stepNo);
    if (!isValid) return;
    handleSubmit(event as any);
  };

  const handleDropdownChange = (e: any, controlName: string) => {
    const value = e.value || '';

    if (controlName === "role" || controlName === "publish") {
      const schema = globalschema[controlName as keyof typeof globalschema];

      if (schema) {
        const result = schema.safeParse(value);
        if (!result.success) {
          setErrors((prev) => ({
            ...prev,
            [controlName]: result.error.errors[0].message,
          }));
          return;
        } else {
          setErrors((prev) => ({ ...prev, [controlName]: '' }));
        }
      }
    }

    const updatedFormData = selectDropdownEnum(e, controlName, false, formData);
    setFormData(updatedFormData);

    switch (controlName) {
      case "publish":
        setSelectedPublishes(value);
        break;
      case "role":
        setSelectedRoles(value);
        break;
      case "verifyShop":
        setSelectedVerifyShop(value);
        break;
      default:
        break;
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (isSubmitting) return;
    setIsSubmitting(true);
    try {

      const payload = {
        ...formData,
        name: `${formData.firstName ? " " + formData.firstName : ""} ${formData.lastName ? " " + formData.lastName : ""}`,
        state: formData.state || 0,
        district: formData.district || 0,
        verifyShopLabel: formData.verifyShop,
        roleLabel: formData.role,
        publishLabel: formData.publish,
      };

      const cleanedPayload = removeEmptyFields(payload);
      let updatedItem;

      if (itemStore.id) {
        updatedItem = { ...cleanedPayload, id: parseInt(itemStore.id.toString(), 10) };
        await itemStore.updateItem(updatedItem);
        setDialogMessage(t('globals.updateDialogMsg', { model: 'App User' }));
      } else {
        await itemStore.addItem(cleanedPayload);
        setDialogMessage(t('globals.addDialogMsg', { model: 'App User' }));
      }
      const emptyFormData = { id: '', name: '', firstName: '', lastName: '', mobile: '', mobileVerified: false, emailId: '', emailVerified: false, shopName: '', password: '', pincode: '', state: '', district: '', address: '', addressLine: '', verifyShop: '', gst: '', gstCertificate: '', photoShopFront: '', visitingCard: '', cheque: '', gstOtp: '', isActive: false, isAdmin: false, hasImpersonateAccess: false, photoAttachment: '', role: '', publish: '', isPremiumUser: false, totalPlot: '', lastLogin: '', defaultLanguage: '' };
      setFormData(emptyFormData);
      listStore.resetStatus();
      itemStore.resetStatus();
      await listStore?.loadList();
      setShowDialog(true);
    } catch (error) {
      console.error("Error:", error);
      if (itemStore.data) {
        alert("Failed to update App User. Please try again later.");
      } else {
        alert("Failed to add App User. Please try again later.");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className='relative h-screen flex flex-col'>
      <div className="flex flex-col overflow-y-auto overflow-x-hidden">
        <div className="flex items-center  p-1 border-b topbar border-[var(--color-border)] shadow-md bg-[var(--color-white)] text-[var(--color-dark)] w-full fixed  top-30 z-20">
          <Button
            className="backBtn cursor-pointer flex items-center"
            onClick={handleBackToUser}
          >
            <BsArrowLeft className="h-6 w-6 cursor-pointer mx-3" />
          </Button>
          <h1 className=" capitalize text-[14px] font-semibold ">{t("globals.backto")} {t("appUsers.form_detail.fields.modelname")}</h1>
        </div>

        <div className="flex flex-col  border-none bg-[var(--color-white)] text-[var(--color-dark)] mb-10 sm:mb-20">
          <form id="myForm" onSubmit={handleSubmit} noValidate>
            <div className="w-full bg-[var(--color-white)] text-[var(--color-dark)]">
              <Stepper ref={stepperRef} headerPosition="top">
                <StepperPanel header={headers[0]}>
                  <div className="p-2 mt-3 lg:mt-10 mb-12 md:mb-0 lg:mb-0 bg-[var(--color-white)] text-[var(--color-dark)]">
                    <div className="user-grid pb-4">
                      {!isFieldHidden("name") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="name"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)]"
                            >
                              {t("appUsers.columns.fields.name")}
                            </label>
                            <span className=" text-[var(--color-danger)] pl-2 ">*</span>
                            <TooltipWithText text={t('appUsers.columns.fields.name')} />
                          </div>

                          <InputText
                            id="name"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t('appUsers.columns.fields.name')}
                            name="name"
                            value={formData.name}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                          />
                          {errors.name && (
                            <p className="text-[var(--color-danger)] text-xs py-2 pl-2">
                              {errors.name}
                            </p>
                          )}
                        </div>
                      )}

                      {!isFieldHidden("firstName") && (
                        <div className="flex flex-col">
                          <div className="flex items-center">
                            <label
                              htmlFor="firstName"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)]"
                            >
                              {t("appUsers.columns.fields.firstName")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.firstName")} />
                          </div>
                          <InputText
                            id="firstName"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.firstName")}
                            name="firstName"
                            value={formData.firstName}
                            onChange={(e) => handleInputChange('firstName', e.target.value)}
                          />
                        </div>
                      )}

                      {!isFieldHidden("lastName") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="lastName"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.lastName")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.lastName")} />
                          </div>
                          <InputText
                            id="lastName"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.lastName")}
                            name="lastName"
                            value={formData.lastName}
                            onChange={(e) => handleInputChange('lastName', e.target.value)}
                          />
                        </div>
                      )}


                      {/* <div className="user-grid pb-4"> */}
                      {!isFieldHidden("mobile") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="mobile"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.mobile")}
                            </label>
                            <span className=" text-[var(--color-danger)] pl-2">*</span>
                            <TooltipWithText text={t("appUsers.columns.fields.mobile")} />
                          </div>
                          <InputText
                            id="mobile"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.mobile")}
                            name="mobile"
                            value={formData.mobile}
                            minLength={10}
                            maxLength={10}
                            onChange={(e) => handleInputChange('mobile', e.target.value)}
                          />
                          {errors.mobile && (
                            <p className="text-[var(--color-danger)] text-xs py-2 pl-2">
                              {errors.mobile}
                            </p>
                          )}
                        </div>
                      )}

                      {!isFieldHidden("mobileVerified") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="mobileVerified"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.mobileVerified")}
                            </label>
                            <span className=" text-[var(--color-danger)] pl-2">*</span>
                            <TooltipWithText text={t("appUsers.columns.fields.mobileVerified")} />
                          </div>
                          <div className="">
                            <Checkbox
                              inputId="mobileVerified"
                              name="mobileVerified"
                              value="mobileVerified"
                              checked={formData.mobileVerified}
                              onChange={(e) =>
                                handleCheckboxChange(e, "mobileVerified")
                              }
                              className="bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            />
                          </div>
                          {errors.mobileVerified && (
                            <p className="text-[var(--color-danger)] text-xs py-2 pl-2">
                              {errors.mobileVerified}
                            </p>
                          )}
                        </div>
                      )}
                      {/* </div> */}
                    </div>
                  </div>
                </StepperPanel>

                <StepperPanel header={headers[1]}>
                  <div className="p-2 mt-3 lg:mt-10 bg-[var(--color-white)] text-[var(--color-dark)] mb-12 md:mb-0 lg:mb-0">
                    <div className="user-grid pb-4">
                      {!isFieldHidden("emailId") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="emailId"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.emailId")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.emailId")} />
                          </div>
                          <InputText
                            id="emailId"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] borderborder-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="email"
                            placeholder={t("appUsers.columns.fields.emailId")}
                            name="emailId"
                            value={formData.emailId}
                            onChange={(e) => handleInputChange('emailId', e.target.value)}
                          />
                        </div>
                      )}

                      {!isFieldHidden("emailVerified") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="emailVerified"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.emailVerified")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.emailVerified")} />
                          </div>
                          <div className="">
                            <Checkbox
                              inputId="emailVerified"
                              name="emailVerified"
                              value="emailVerified"
                              checked={formData.emailVerified}
                              onChange={(e) =>
                                handleCheckboxChange(e, "emailVerified")
                              }
                              className="bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            />
                          </div>
                          {errors.emailVerified && (
                            <p className="text-[var(--color-danger)] text-xs py-2 pl-2">
                              {errors.emailVerified}
                            </p>
                          )}
                        </div>
                      )}

                      {!isFieldHidden("shopName") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="shopName"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.shopName")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.shopName")} />
                          </div>
                          <InputText
                            id="shopName"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.shopName")}
                            name="shopName"
                            value={formData.shopName}
                            onChange={(e) => handleInputChange('shopName', e.target.value)}
                          />
                        </div>
                      )}
                   

                    {/* <div className="user-grid pb-4"> */}
                      {!isFieldHidden("password") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="password"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.password")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.password")} />
                          </div>
                          <InputText
                            id="password"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="password"
                            placeholder={t("appUsers.columns.fields.password")}
                            name="password"
                            value={formData.password}
                            onChange={(e) => handleInputChange('password', e.target.value)}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </StepperPanel>

                <StepperPanel header={headers[2]}>
                  <div className="p-2 mt-3 lg:mt-10 bg-[var(--color-white)] text-[var(--color-dark)] mb-12 md:mb-0 lg:mb-0">
                    <div className="user-grid pb-4">
                      {!isFieldHidden("pincode") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="pincode"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.pincode")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.pincode")} />
                          </div>
                          <InputText
                            id="pincode"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.pincode")}
                            name="pincode"
                            value={formData.pincode}
                            onChange={(e) => handleInputChange('pincode', e.target.value)}
                          />
                        </div>
                      )}

                      {!isFieldHidden("state") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="state"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.state")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.state")} />
                          </div>
                          <InputText
                            id="state"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)]  border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.state")}
                            name="state"
                            value={formData.state}
                            onChange={(e) => handleInputChange('state', e.target.value)}
                          />
                        </div>
                      )}

                      {!isFieldHidden("district") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="district"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.district")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.district")} />
                          </div>
                          <InputText
                            id="district"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.district")}
                            name="district"
                            value={formData.district}
                            onChange={(e) => handleInputChange('district', e.target.value)}
                          />
                        </div>
                      )}
                    {/* </div> */}

                    {/* <div className="user-grid pb-4"> */}
                      {!isFieldHidden("address") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="address"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.address")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.address")} />
                          </div>
                          <InputTextarea
                            id="address"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)]  border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            placeholder={t("appUsers.columns.fields.address")}
                            name="address"
                            value={formData.address}
                            onChange={(e) => handleInputChange('address', e.target.value)}
                          />
                        </div>
                      )}

                      {!isFieldHidden("addressLine") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="addressLine"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.addressLine")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.addressLine")} />
                          </div>
                          <InputTextarea
                            id="addressLine"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            placeholder={t("appUsers.columns.fields.addressLine")}
                            name="addressLine"
                            value={formData.addressLine}
                            onChange={(e) => handleInputChange('addressLine', e.target.value)}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </StepperPanel>

                <StepperPanel header={headers[3]}>
                  <div className="p-2 mb-12 md:mb-0 lg:mb-0 bg-[var(--color-white)] text-[var(--color-dark)] mt-3 lg:mt-10">
                    <div className="user-grid pb-4">
                      {!isFieldHidden("verifyShop") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="verifyShop"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)]"
                            >
                              {t("appUsers.columns.fields.verifyShop")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.verifyShop")} />
                          </div>
                          <Dropdown
                            id="verifyShop"
                            name="verifyShop"
                            value={selectedVerifyShop}
                            onChange={(e) => handleDropdownChange(e, "verifyShop")}
                            options={listVerifyShop}
                            optionLabel="name"
                            placeholder={t("appUsers.columns.fields.verifyShop")}
                            filter
                            className="dropdowndark text-sm w-full lg:w-20rem flex items-center h-[40px]  bg-[var(--color-white)] text-[var(--color-dark)] dropdowndark"
                          />
                        </div>
                      )}

                      {!isFieldHidden("gst") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="gst"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.gst")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.gst")} />
                          </div>
                          <InputText
                            id="gst"
                            name="gst"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.gst")}
                            value={formData.gst}
                            onChange={(e) => handleInputChange('gst', e.target.value)}
                          />
                        </div>
                      )}

                      {!isFieldHidden("gstCertificate") && (
                        <div className="flex flex-col">
                          <div className="flex items-center">
                            <label
                              htmlFor="gstCertificate"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.gstCertificate")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.gstCertificate")} />
                          </div>
                          <FileUploadMain
                            modelName="AppUser"
                            propName="gstCertificate"
                            onFileUpload={(files) => handleFileUpload(files, 'gstCertificate')}
                            accept=".jpg,.jpeg,.png,.pdf"
                            initialData={formData.gstCertificate}
                            maxFileNumber={2}
                          />
                        </div>
                      )}
                    {/* </div> */}

                    {/* <div className="user-grid pb-4"> */}
                      {!isFieldHidden("photoShopFront") && (
                        <div className="flex flex-col">
                          <div className="flex items-center">
                            <label
                              htmlFor="photoShopFront"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.photoShopFront")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.photoShopFront")} />
                          </div>

                          <FileUploadMain
                            modelName="AppUser"
                            propName="photoShopFront"
                            onFileUpload={(files) => handleFileUpload(files, 'photoShopFront')}
                            accept=".jpg,.jpeg,.png,.pdf"
                            initialData={formData.photoShopFront}
                            maxFileNumber={2}
                          />
                        </div>
                      )}

                      {!isFieldHidden("visitingCard") && (
                        <div className="flex flex-col">
                          <div className="flex items-center">
                            <label
                              htmlFor="visitingCard"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.visitingCard")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.visitingCard")} />
                          </div>
                          <FileUploadMain
                            modelName="AppUser"
                            propName="visitingCard"
                            onFileUpload={(files) => handleFileUpload(files, 'visitingCard')}
                            accept=".jpg,.jpeg,.png,.pdf"
                            initialData={formData.visitingCard}
                            maxFileNumber={2}
                          />
                        </div>
                      )}

                      {!isFieldHidden("cheque") && (
                        <div className="flex flex-col">
                          <div className="flex items-center">
                            <label
                              htmlFor="cheque"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.cheque")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.cheque")} />
                          </div>

                          <FileUploadMain
                            modelName="AppUser"
                            propName="cheque"
                            onFileUpload={(files) => handleFileUpload(files, 'cheque')}
                            accept=".jpg,.jpeg,.png,.pdf"
                            initialData={formData.cheque}
                            maxFileNumber={1}
                          />
                        </div>
                      )}
                    {/* </div> */}

                    {/* <div className="user-grid pb-4"> */}
                      {!isFieldHidden("gstOtp") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="gstOtp"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.gstOtp")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.gstOtp")} />
                          </div>
                          <InputText
                            id="gstOtp"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.gstOtp")}
                            name="address"
                            value={formData.gstOtp}
                            onChange={(e) => handleInputChange('gstOtp', e.target.value)}
                          />
                        </div>
                      )}

                      {!isFieldHidden("isActive") && (
                        <div className="flex flex-col">
                          <div className="flex items-center">
                            <label
                              htmlFor="isActive"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.isActive")}
                            </label>
                            <span className=" text-[var(--color-danger)] pl-2">*</span>
                            <TooltipWithText text={t("appUsers.columns.fields.isActive")} />
                          </div>
                          <div>
                            <Checkbox
                              inputId="isActive"
                              name="isActive"
                              value="isActive"
                              checked={formData.isActive}
                              onChange={(e) =>
                                handleCheckboxChange(e, "isActive")
                              }
                              className="bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            />
                          </div>
                          {errors.isActive && (
                            <p className="text-[var(--color-danger)] text-xs py-2 pl-2">
                              {errors.isActive}
                            </p>
                          )}
                        </div>
                      )}

                      {!isFieldHidden("isAdmin") && (
                        <div className="flex flex-col">
                          <div className="flex items-center">
                            <label
                              htmlFor="isAdmin"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)]"
                            >
                              {t("appUsers.columns.fields.isAdmin")}
                            </label>
                            <span className=" text-[var(--color-danger)] pl-2">*</span>
                            <TooltipWithText text={t("appUsers.columns.fields.isAdmin")} />
                          </div>
                          <div className="">
                            <Checkbox
                              inputId="isAdmin"
                              name="isAdmin"
                              value="isAdmin"
                              checked={formData.isAdmin}
                              onChange={(e) => handleCheckboxChange(e, "isAdmin")}
                              className="bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            />
                          </div>
                          {errors.isAdminError && (
                            <p className="text-[var(--color-danger)] text-xs py-2 pl-2">
                              {errors.isAdminError}
                            </p>
                          )}
                        </div>
                      )}
                    {/* </div> */}

                    {/* <div className="user-grid pb-4"> */}
                      {!isFieldHidden("hasImpersonateAccess") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="hasImpersonateAccess"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)]"
                            >
                              {t("appUsers.columns.fields.hasImpersonateAccess")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.hasImpersonateAccess")} />
                          </div>
                          <div className="">
                            <Checkbox
                              inputId="hasImpersonateAccess"
                              name="hasImpersonateAccess"
                              value="hasImpersonateAccess"
                              checked={formData.hasImpersonateAccess}
                              onChange={(e) =>
                                handleCheckboxChange(e, "hasImpersonateAccess")
                              }
                              className="bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            />
                          </div>
                        </div>
                      )}

                      {!isFieldHidden("photoAttachment") && (
                        <div className="flex flex-col">
                          <div className="flex items-center">
                            <label
                              htmlFor="photoAttachment"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)]"
                            >
                              {t("appUsers.columns.fields.photoAttachment")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.photoAttachment")} />
                          </div>
                          <FileUploadMain
                            modelName="AppUser"
                            propName="photoAttachment"
                            onFileUpload={(files) => handleFileUpload(files, 'photoAttachment')}
                            accept=".jpg,.jpeg,.png,.pdf"
                            initialData={formData.photoAttachment}
                            maxFileNumber={2}
                          />
                        </div>
                      )}

                      {!isFieldHidden("role") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="role"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.role")}
                            </label>
                            <span className=" text-[var(--color-danger)] pl-2">*</span>
                            <TooltipWithText text={t("appUsers.columns.fields.role")} />
                          </div>
                          <Dropdown
                            id="role"
                            name="role"
                            value={selectedRoles}
                            onChange={(e) => handleDropdownChange(e, "role")}
                            options={listRoles}
                            placeholder={t("appUsers.columns.fields.role")}
                            optionLabel="name"
                            filter
                            className="dropdowndark text-sm w-full lg:w-20rem flex items-center h-[40px]  bg-[var(--color-white)] text-[var(--color-dark)] "
                          />
                          {errors.role && (
                            <p className="text-[var(--color-danger)] text-xs py-2 pl-2">
                              {errors.role}
                            </p>
                          )}
                        </div>
                      )}
                    {/* </div> */}

                    {/* <div className="user-grid pb-4"> */}
                      {!isFieldHidden("publish") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="publish"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)]  "
                            >
                              {t("appUsers.columns.fields.publish")}
                            </label>
                            <span className=" text-[var(--color-danger)] pl-2">*</span>
                            <TooltipWithText text={t("appUsers.columns.fields.publish")} />
                          </div>
                          <Dropdown
                            id="publish"
                            name="publish"
                            value={selectedPublishes}
                            onChange={(e) => handleDropdownChange(e, "publish")}
                            options={listPublishes}
                            optionLabel="name"
                            placeholder={t("appUsers.columns.fields.publish")}
                            filter
                            className="dropdowndark text-sm w-full lg:w-20rem flex items-center h-[40px]  bg-[var(--color-white)] text-[var(--color-dark)] "
                          />
                          {errors.publish && (
                            <p className="text-[var(--color-danger)] text-xs py-2 pl-2">
                              {errors.publish}
                            </p>
                          )}
                        </div>
                      )}

                      {!isFieldHidden("lastLogin") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="lastLogin"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.lastLogin")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.lastLogin")} />
                          </div>
                          <Calendar
                            value={formData.lastLogin ? new Date(formData.lastLogin) : null}
                            dateFormat="mm-dd-yy"
                            name="CreateDateFrom"
                            onChange={(e) => handleInputChange('lastLogin', e.value ? formatDate(e.value) : '')}
                            showIcon
                            placeholder={t("appUsers.columns.fields.lastLogin")}
                            className="calendardark text-sm rounded-md py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                          />
                        </div>
                      )}

                      {!isFieldHidden("defaultLanguage") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="defaultLanguage"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.defaultLanguage")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.defaultLanguage")} />
                          </div>
                          <InputText
                            id="defaultLanguage"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.defaultLanguage")}
                            name="defaultLanguage"
                            value={formData.defaultLanguage}
                            onChange={(e) => handleInputChange('defaultLanguage', e.target.value)}
                          />
                        </div>
                      )}
                    {/* </div> */}

                    {/* <div className="user-grid pb-4"> */}
                      {!isFieldHidden("isPremiumUser") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="isPremiumUser"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.isPremiumUser")}
                            </label>
                            <TooltipWithText text="IsPremiumUser" />
                          </div>
                          <div className="">
                            <Checkbox
                              inputId="isPremiumUser"
                              name="isPremiumUser"
                              value="isPremiumUser"
                              checked={formData.isPremiumUser}
                              onChange={(e) =>
                                handleCheckboxChange(e, "isPremiumUser")
                              }
                              className="bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            />
                          </div>
                        </div>
                      )}

                      {!isFieldHidden("totalPlot") && (
                        <div className="flex flex-col">
                          <div className=" flex items-center">
                            <label
                              htmlFor="totalPlot"
                              className="text-sm font-bold py-2 bg-[var(--color-white)] text-[var(--color-dark)] "
                            >
                              {t("appUsers.columns.fields.totalPlot")}
                            </label>
                            <TooltipWithText text={t("appUsers.columns.fields.totalPlot")} />
                          </div>
                          <InputText
                            id="totalPlot"
                            className="rounded-md text-sm py-2 px-3 bg-[var(--color-white)] text-[var(--color-dark)] border border-[var(--color-border)] focus:border-[var(--color-primary)] focus:ring-[var(--color-primary)]"
                            type="text"
                            placeholder={t("appUsers.columns.fields.totalPlot")}
                            name="totalPlot"
                            value={formData.totalPlot}
                            onChange={(e) => handleInputChange('totalPlot', e.target.value)}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </StepperPanel>
              </Stepper>
            </div>
          </form>
        </div>

        <div className="fixed bottom-0 z-auto  bg-[var(--color-white)] text-[var(--color-dark)] shadow-lg border-t border-[var(--color-border)] p-2 available-width">
          <div className="flex gap-2  px-3">
            {stepNo > 0 && (
              <Button
                type="button"
                className="bg-[#f9fafb] rounded-md p-2 w-[100px] text-[var(--color-primary)] bg-[var(--color-white)]  border-2 border-[var(--color-primary)] font-medium text-[13px] flex items-center justify-center space-x-2"
                onClick={previous}
              >
                <IoIosArrowBack size={15} className="text-[var(--color-primary)]" />
                <span>{t("globals.previous")}</span>
              </Button>
            )}

            {stepNo !== headers.length - 1 && (
              <Button
                type="button"
                className="bg-[var(--color-primary)] rounded-md p-2 w-[100px] text-[var(--color-white)] font-medium text-[13px] flex items-center justify-center space-x-2"
                onClick={next}
              >
                <span>{t("globals.next")}</span>
                <IoIosArrowForward size={15} className="text-[var(--color-white)]" />
              </Button>
            )}

            {stepNo === headers.length - 1 && (
              <Button
                type="button"
                className={`p-2 w-[100px] rounded-md font-medium text-[13px] flex items-center justify-center 
                      bg-[var(--color-primary)] text-white disabled:bg-[#9ca3af] disabled:text-black disabled:cursor-not-allowed`}
                onClick={handleSubmitClick}
              >
                <span>{t("globals.save")}</span> <FaSave size={15} />
              </Button>
            )}
          </div>
        </div>
      </div>

      <Toast ref={toast} />

      <Dialog
        visible={showDialog}
        onHide={handleCloseDialog}
        className="w-[350px]"
      >
        <div className="flex flex-col items-center p-3">
          <Image
            src={successImg}
            alt="Record Deleted Successfully"
            className="h-[100px] w-[100px] lg:h-[150px] lg:w-[150px] object-cover rounded-full"
          />
          <div className="text-center">
            <p className="text-[16px] font-semibold text-black">{dialogMessage}</p>
            {/* <h2 className="text-xl font-semibold text-emerald-700">Successfully!</h2> */}
          </div>
        </div>
      </Dialog>
    </div>
  )
}

