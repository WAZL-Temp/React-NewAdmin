import { Product } from "../../../core/model/product";
import { createListStore } from "../../../store/createListStore";
import { productService } from "../../../core/services/productService";


export const productListStore = createListStore<Product>(productService,"Product");


