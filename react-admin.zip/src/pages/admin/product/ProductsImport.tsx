import { useState } from "react";
import { productService } from "../../../core/services/productService";
import { Product } from '../../../core/model/product';
import { BsArrowLeft, Button, Column, DataTable, Dialog, Image, RiEyeFill, RiFileDownloadFill, RiFileFill, SplitButton, Tooltip, useTranslation } from '../../../sharedBase/globalImports';
import FileUploadMain from '../../../components/FileUploadMain';
import { FileUploadService } from "../../../core/services/fileuploadservice";
import { useImportPage } from "../../../hooks/useImportPage";
import TableSkeleton from "../../../components/TableSkeleton";
import successimg from '../../../assets/images/success.gif';

interface CustomFile {
  fileName: string;
  filePath: string;
  type: string;
}

const ProductsImport = () => {
  const { t } = useTranslation();
  const [errors, setErrors] = useState<{ importFile: string }>({ importFile: '' });
  const [showTable, setShowTable] = useState<boolean>(false);
  const [importedData, setImportedData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<any>(null);
  const fileUploadService = new FileUploadService("Product")
  const [validFile, setValidFile] = useState(false);
  const [importValidateComplete, setImportValidateComplete] = useState(false);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [importSyncComplete, setImportSyncComplete] = useState(false);
  const [loadingSync, setLoadingSync] = useState(false);
  const baseModelName = "Product";
  const { onPage, first, rows, handleDownloadTemplate, downloading, importAllow }
    = useImportPage<Product>({
      props: {
        baseModelName: baseModelName,
        service: productService
      }
    });

  const items = [
    {
      label:t("globals.emptyTemplate"),
      icon: <RiFileFill style={{ color: '#059669' }} />,
      command: () => handleDownloadTemplate(false)
    },
    {
      label: t("globals.sampleTemplate"),
      icon: <RiFileFill style={{ color: '#3B82F6' }} />,
      command: () => handleDownloadTemplate(true)
    }
  ];

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!uploadedFile) {
      setErrors({ importFile: 'Import File is required!' });
    } else {
      setErrors({ importFile: '' });
      setLoading(true);
      setShowTable(true);

      try {
        const importedData = await fileUploadService.getImportData(uploadedFile[0]);
        setImportedData(importedData);
        setTotalRecords(importedData.length);

        let inValidFile = false;
        importedData.forEach((item: any) => {
          if (item.remark != null || (item.importRemark && item.importRemark.length > 2)) {
            inValidFile = true;
          }
        });
        setValidFile(!inValidFile);
        setImportValidateComplete(true);


      } catch (error) {
        console.error('Error during file upload or data import:', error);
        setImportedData([]);
        setTotalRecords(0);
      } finally {
        setLoading(false);
      }
    }
  };

  const syncImportData = async () => {
    try {

      if (!uploadedFile) {
        console.error("No file uploaded")
        return
      }
      setImportSyncComplete(true);
      setLoading(true);
      setLoadingSync(true);
      const response = await fileUploadService.syncImportData(uploadedFile);
      if (response && response.length > 0) {
        setLoadingSync(false);
        setTimeout(() => {
          setImportSyncComplete(false);
        }, 2000);
      }
    } catch (error) {
      console.error("Error syncing data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleFileUpload = (files: CustomFile) => {
    setUploadedFile(files);
  };

  const columns = [
    { field: 'importAction', header: t("products.form_detail.fields.importAction") },
    { field: 'importRemark', header: t("products.form_detail.fields.importRemark") },
    { field: "name", header: t("products.columns.fields.name") },
    { field: "slug", header: t("products.columns.fields.slug") },
    { field: "sku", header: t("products.columns.fields.sku") },
    { field: "specifications", header: t("products.columns.fields.specifications") },
    { field: "shippingAmount", header: t("products.columns.fields.shippingAmount") },
    { field: "regularPrice", header: t("products.columns.fields.regularPrice") },
    { field: "salePrice", header: t("products.columns.fields.salePrice") },
    { field: "cgst", header: t("products.columns.fields.cgst") },
    { field: "sgst", header: t("products.columns.fields.sgst") },
    { field: "igst", header: t("products.columns.fields.igst") },
    { field: "categoryId", header: t("products.columns.fields.categoryId") },
    { field: "productStatus", header: t("products.columns.fields.productStatus") },
    { field: "category", header: t("products.columns.fields.category") },
    { field: "minQty", header: t("products.columns.fields.minQty") },
    { field: "minQtyFarmer", header: t("products.columns.fields.minQtyFarmer") },
    { field: "salePriceFarmer", header: t("products.columns.fields.salePriceFarmer") },
    { field: "isActive", header: t("products.columns.fields.isActive"), boolean: true },
    { field: "orderNo", header: t("products.columns.fields.orderNo") },
    { field: "deliveredData", header: t("products.columns.fields.deliveredData") },
    { field: "totalDeliverProduct", header: t("products.columns.fields.totalDeliverProduct") },
    { field: "isParent", header: t("products.columns.fields.isParent"), boolean: true },
    { field: "variableLabel", header: t("products.columns.fields.variableLabel") },
    { field: "variableValue", header: t("products.columns.fields.variableValue") },
  ];


  return (
    <div className="relative flex flex-col h-screen overflow-y-auto overflow-x-hidden mb-20">
      <div className="flex items-center topbar p-1 bg-[var(--color-white] text-[var(--color-dark)] w-full fixed top-30 z-20">
        <Button
          className="backBtn cursor-pointer flex items-center"
          onClick={() => window.history.back()}
        >
          <BsArrowLeft className=" h-7 w-7 cursor-pointer mx-3" />
        </Button>
        <h1 className=" capitalize text-[14px] font-semibold ">{t("globals.backto")} {t("products.form_detail.fields.modelname")}</h1>
      </div>

      <div className="flex flex-col h-full pt-10 px-4">
        <div className="import-grid">
          <div className="bg-[var(--color-white] border border-[var(--color-border)] shadow-md rounded-md p-1 lg:p-2">
            <form onSubmit={handleSubmit} noValidate>
              <div className="flex flex-col md:flex-row lg:items-start items-center justify-center lg:justify-between gap-2 md:gap-4">
                <div className="flex justify-center items-center gap-2 w-full md:w-auto">
                  <label htmlFor="importFile" className="text-[14px] font-bold  text-[var(--color-dark)]">
                    {t("globals.importFile")}
                  </label>
                  <span className="text-[var(--color-danger)]">*</span>
                </div>

                <div className="flex items-center text-[var(--color-primary)] w-[200px]">
                  <FileUploadMain
                    modelName="AppUser"
                    propName="importFile"
                    onFileUpload={(files: any) => handleFileUpload(files)}
                    multiple={false}
                    accept=".xlsx"
                    initialData={uploadedFile}
                    maxFileNumber={1}

                  />
                </div>

                <Button
                  type="submit"
                  className={`flex items-center text-sm gap-2 px-4 py-2 rounded-lg ${uploadedFile ? 'bg-[var(--color-primary)] text-[var(--color-white)]' : 'bg-[#6B7280] opacity-50 cursor-not-allowed'}`}
                  disabled={!uploadedFile || validFile}
                >
                  <RiEyeFill />
                  {t("globals.preview")}
                </Button>
              </div>

              {errors.importFile && (
                <p className="text-[var(--color-danger)] text-xs mt-1">
                  {errors.importFile}
                </p>
              )}
            </form>
          </div>

          <div className="p-1 md:p-2 shadow-md rounded-md flex flex-wrap items-center justify-center lg:justify-between gap-4 w-full">
            <SplitButton
              label={t("globals.downloadTemplates")}
              model={items}
              icon={<RiFileDownloadFill className="mr-2 text-[var(--color-primary)]" size={16} />}
              className="w-[200px] border border-[var(--color-border)] p-1 lg:p-2 text-sm font-normal"
              disabled={downloading}
            />
          </div>
        </div>

        {(importAllow || importValidateComplete) && showTable && (
          <div className="bg-[var(--color-white] border-[var(--color-border)] rounded-md my-4">
            <div className=" container-fluid pb-28">
              {loading ? (
                <TableSkeleton cols={columns} />
              ) : (
                <>
                  <DataTable
                    value={importedData}
                    dataKey="slug"
                    resizableColumns
                    scrollable
                    scrollHeight="calc(100vh - 300px)"
                    showGridlines
                    paginator
                    first={first}
                    rows={rows}
                    totalRecords={totalRecords}
                    onPage={onPage}
                    paginatorTemplate={t('globals.layout')}
                    currentPageReportTemplate={t('globals.report')}
                    emptyMessage={t('globals.emptyMessage')}
                    rowsPerPageOptions={[10, 25, 50]}
                    className="p-datatable-gridlines datatable-responsive bg-[var(--color-white)] tableResponsive"
                  >
                    <Column
                      field="importAction" header={t("products.form_detail.fields.importAction")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-importAction-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.importAction}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-importAction-${rowIndex}`} content={rowData.importAction} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="importRemark" header={t("products.form_detail.fields.importRemark")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-importRemark-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.importRemark}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-importRemark-${rowIndex}`} content={rowData.importRemark} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="name" header={t("products.columns.fields.name")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-name-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.name}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-name-${rowIndex}`} content={rowData.name} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="slug" header={t("products.columns.fields.slug")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-slug-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.slug}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-slug-${rowIndex}`} content={rowData.slug} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="sku" header={t("products.columns.fields.sku")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-sku-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.sku}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-sku-${rowIndex}`} content={rowData.sku} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="specifications" header={t("products.columns.fields.specifications")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-specifications-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.specifications}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-specifications-${rowIndex}`} content={rowData.specifications} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="shippingAmount" header={t("products.columns.fields.shippingAmount")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-shippingAmount-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.shippingAmount}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-shippingAmount-${rowIndex}`} content={rowData.shippingAmount} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="regularPrice" header={t("products.columns.fields.regularPrice")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-regularPrice-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.regularPrice}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-regularPrice-${rowIndex}`} content={rowData.regularPrice} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="salePrice" header={t("products.columns.fields.salePrice")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-salePrice-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.salePrice}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-salePrice-${rowIndex}`} content={rowData.salePrice} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="cgst" header={t("products.columns.fields.cgst")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-cgst-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.cgst}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-cgst-${rowIndex}`} content={rowData.cgst} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="sgst" header={t("products.columns.fields.sgst")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-sgst-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.sgst}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-sgst-${rowIndex}`} content={rowData.sgst} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="igst" header={t("products.columns.fields.igst")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-igst-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.igst}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-igst-${rowIndex}`} content={rowData.igst} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="categoryId" header={t("products.columns.fields.categoryId")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-categoryId-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.categoryId}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-categoryId-${rowIndex}`} content={rowData.categoryId} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="productStatus" header={t("products.columns.fields.productStatus")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-productStatus-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.pincode}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-productStatus-${rowIndex}`} content={rowData.productStatus} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="category" header={t("products.columns.fields.category")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-category-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.category}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-category-${rowIndex}`} content={rowData.category} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="minQty" header={t("products.columns.fields.minQty")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-minQty-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.minQty}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-minQty-${rowIndex}`} content={rowData.minQty} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="minQtyFarmer" header={t("products.columns.fields.minQtyFarmer")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-minQtyFarmer-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.minQtyFarmer}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-minQtyFarmer-${rowIndex}`} content={rowData.minQtyFarmer} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="salePriceFarmer" header={t("products.columns.fields.salePriceFarmer")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-salePriceFarmer-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.salePriceFarmer}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-salePriceFarmer-${rowIndex}`} content={rowData.salePriceFarmer} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="isActive" header={t("products.columns.fields.isActive")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-isActive-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.isActive ? "true" : "false"}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-isActive-${rowIndex}`} content={rowData.isActive} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="orderNo" header={t("products.columns.fields.orderNo")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-orderNo-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.orderNo}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-orderNo-${rowIndex}`} content={rowData.orderNo} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="deliveredData" header={t("products.columns.fields.deliveredData")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-deliveredData-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.deliveredData}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-deliveredData-${rowIndex}`} content={rowData.deliveredData} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="totalDeliverProduct" header={t("products.columns.fields.totalDeliverProduct")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-totalDeliverProduct-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.totalDeliverProduct}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-totalDeliverProduct-${rowIndex}`} content={rowData.totalDeliverProduct} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="isParent" header={t("products.columns.fields.isParent")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-isParent-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.isParent ? "true" : "false"}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-isParent-${rowIndex}`} content={rowData.isParent} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="variableLabel" header={t("products.columns.fields.variableLabel")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-variableLabel-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.variableLabel}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-variableLabel-${rowIndex}`} content={rowData.variableLabel} showDelay={200} position="top" />
                        </>
                      )}
                    />
                    <Column
                      field="variableValue" header={t("products.columns.fields.variableValue")} sortable
                      headerStyle={{ backgroundColor: "var(--color-primary)", color: "var(--color-white)", textAlign: "center" }}
                      style={{ width: "200px", backgroundColor: "var(--color-white)" }}
                      body={(rowData, { rowIndex }) => (
                        <>
                          <div id={`tooltip-variableValue-${rowIndex}`} className="text-left truncate font-medium">
                            {rowData.variableValue}
                          </div>
                          <Tooltip className="text-xs font-semibold hide-tooltip-mobile" target={`#tooltip-variableValue-${rowIndex}`} content={rowData.variableValue} showDelay={200} position="top" />
                        </>
                      )}
                    />
                  </DataTable>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      {importAllow && importValidateComplete && (
        <div className=" button-container">
          <Button
            label={t("globals.syncData")}
            className={`border-[var(--color-border)] bg-[var(--color-primary)] text-[var(--color-white)] text-sm p-2 px-4 rounded-lg shadow-md ${validFile ? 'bg-[var(--color-primary)] text-[var(--color-dark)]' : 'bg-[#6B7280] opacity-50 cursor-not-allowed'}`}
            onClick={() => syncImportData()}
            disabled={!validFile}
          />
        </div>
      )}

      <Dialog visible={importSyncComplete} onHide={() => setImportSyncComplete(false)} >
        <div className="p-0 max-w-sm mx-auto">
          <div className="flex justify-between items-center border-b">
            <button
              onClick={() => setImportSyncComplete(false)}
              className="text-[#6b7280] hover:text-[#6b7280]"
            >
              <i className="ri-close-fill text-xl"></i>
            </button>
          </div>
          <div className="flex flex-col items-center p-3">
            <Image
              src={successimg}
              alt="Record imported Successfully"
              className="h-[150px] w-[150px] lg:h-[150px] lg:w-[150px] object-cover rounded-full"
            />
            <div className="text-center">
              <h2 className="text-lg text-black font-semibold mb-2">{t("globals.importDialogMsg")}</h2>
              {loadingSync && (
                <h2 className="text-sm text-black font-normal mb-2">{t("globals.importDialogProcessMsg")}</h2>
              )}
            </div>
          </div>
        </div>
      </Dialog>
    </div >
  )
};

export default ProductsImport;

