import { useEffect, useState } from "react";
import { BrowserRouter, Navigate, Route, Routes } from './sharedBase/globalImports';
import Layout from './components/Layout';
import LoginPage from './pages/auth/LoginPage';
import AuthGuard from '../src/components/AuthGuard';
import NotAuthorized from './pages/NotAuthorize';
import ProductsList from './pages/admin/product/ProductsList';
import AppUserHomePage from './pages/admin/appuser/AppUsersHome';
import AppUsersImport from './pages/admin/appuser/AppUsersImport';
import AppUsersView from './pages/admin/appuser/AppUsersView';
import AppUsersEdit from './pages/admin/appuser/AppUsersEdit';
import AppUsersList from './pages/admin/appuser/AppUsersList';
import ProductsImport from './pages/admin/product/ProductsImport';
import { enumDetailStore } from "./store/enumDetailsStore";
import RoleDetailsForm from "./pages/admin/role/RoleDetailsForm";
import AppUsersTestList from "./pages/admin/appuser/AppUsersTestList";


const App = () => {
  const { loadList, data } = enumDetailStore();
  const [pageLoad, setPageLoad] = useState(false);

  useEffect(() => {
    if (data.length) {
      setPageLoad(true);
    }

    const EnumDataCall = async () => {
      await loadList();
    };

    EnumDataCall();
  }, [data]);

  return (
    pageLoad ? (
      <div className="font-custom">
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/appuser" element={<AuthGuard requiredAction="List" page="appUser"><Layout><AppUsersList /></Layout></AuthGuard>} />
            <Route path="/appusertests" element={<Layout><AppUsersTestList /></Layout>} />
            <Route path="/appuser/homes" element={<Layout><AppUserHomePage /></Layout>} />
            <Route path="/appuser/import" element={<AuthGuard requiredAction="Import" page="appUser"><Layout><AppUsersImport /></Layout></AuthGuard>} />
            <Route path="/appuser/:id" element={<AuthGuard requiredAction="View" page="appUser"><Layout><AppUsersView /></Layout></AuthGuard>} />
            <Route path="/appuser/edit/:id" element={<AuthGuard requiredAction="Edit" page="appUser"><Layout><AppUsersEdit /></Layout></AuthGuard>} />
            <Route path="/appuser/add/" element={<AuthGuard requiredAction="Add" page="appUser"><Layout><AppUsersEdit /></Layout></AuthGuard>} />
            <Route path="/product" element={<AuthGuard requiredAction="List" page="product"><Layout><ProductsList /></Layout></AuthGuard>} />
            <Route path="/product/import" element={<AuthGuard requiredAction="Import" page="product"><Layout><ProductsImport /></Layout></AuthGuard>} />
            <Route path="/role" element={<Layout><RoleDetailsForm /></Layout>} />

            <Route path="/404" element={<Layout><NotAuthorized /></Layout>} />
            <Route path="*" element={<Navigate to="/404" replace />} />
          </Routes>
        </BrowserRouter>
      </div>
    ) : (
      <div>Loading...</div>
    )
  )
};

export default App;
