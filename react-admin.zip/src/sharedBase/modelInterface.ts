export interface BaseModel {
  slug?: string;
  id?: number;
  name?: string;
}
